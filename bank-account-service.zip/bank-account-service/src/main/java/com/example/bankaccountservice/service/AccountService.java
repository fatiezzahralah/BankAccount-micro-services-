package com.example.bankaccountservice.service;

import com.example.bankaccountservice.dto.BankAccountRequestDto;
import com.example.bankaccountservice.dto.BankAccountResponseDTO;
import com.example.bankaccountservice.entities.BankAccount;

public interface AccountService {
  BankAccountResponseDTO addAccount(BankAccountRequestDto bankAccountDto);

  BankAccountResponseDTO updateAccount(String id, BankAccountRequestDto bankAccountDto);



}
